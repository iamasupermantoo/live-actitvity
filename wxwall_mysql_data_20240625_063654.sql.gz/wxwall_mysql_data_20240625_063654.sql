-- MySQL dump 10.13  Distrib 5.6.50, for Linux (aarch64)
--
-- Host: localhost    Database: wxwall
-- ------------------------------------------------------
-- Server version	5.6.50-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `weixin_admin`
--

DROP TABLE IF EXISTS `weixin_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_admin` (
  `user` text NOT NULL,
  `pwd` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_admin`
--

LOCK TABLES `weixin_admin` WRITE;
/*!40000 ALTER TABLE `weixin_admin` DISABLE KEYS */;
INSERT INTO `weixin_admin` VALUES ('robinson','aa111111');
/*!40000 ALTER TABLE `weixin_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_aliyunoss`
--

DROP TABLE IF EXISTS `weixin_aliyunoss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_aliyunoss` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `OSS_ACCESS_ID` varchar(255) DEFAULT NULL COMMENT 'ACCESS_ID',
  `OSS_ACCESS_KEY` varchar(255) DEFAULT NULL COMMENT 'ACCESS_KEY',
  `ALI_LOG` tinyint(1) DEFAULT '1' COMMENT '1不记录日志2记录日志',
  `ALI_LOG_PATH` varchar(255) DEFAULT NULL COMMENT '日志存放路径',
  `ALI_DISPLAY_LOG` tinyint(1) DEFAULT '1' COMMENT '是否显示日志输出1不显示2显示',
  `BUCKET_NAME` varchar(255) DEFAULT NULL COMMENT 'bucket名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='阿里云oss配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_aliyunoss`
--

LOCK TABLES `weixin_aliyunoss` WRITE;
/*!40000 ALTER TABLE `weixin_aliyunoss` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_aliyunoss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_attachments`
--

DROP TABLE IF EXISTS `weixin_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filepath` varchar(255) DEFAULT NULL COMMENT '文件路径',
  `extension` varchar(10) DEFAULT NULL COMMENT '扩展名',
  `type` tinyint(1) DEFAULT NULL COMMENT '1本地文件2阿里云3新浪云',
  `filemd5` varchar(32) DEFAULT NULL COMMENT '文件名和文件大小组合的md5值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='附件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_attachments`
--

LOCK TABLES `weixin_attachments` WRITE;
/*!40000 ALTER TABLE `weixin_attachments` DISABLE KEYS */;
INSERT INTO `weixin_attachments` VALUES (1,'/wall/themes/meepo/assets/images/shake/worldcup/football1.gif','gif',1,'5aa0060a952e110c494530036fd5c5b7'),(2,'/wall/themes/meepo/assets/images/shake/worldcup/football2.gif','gif',1,'a8c965007337f76590b8dfdf2827a7a6'),(3,'/wall/themes/meepo/assets/images/shake/worldcup/football3.gif','gif',1,'0fd0c04960211d1a55328cdda9e57551'),(4,'/wall/themes/meepo/assets/images/shake/worldcup/football4.gif','gif',1,'c860c8a5b63b76d6b73b4e2dbe6302d6'),(5,'/wall/themes/meepo/assets/images/shake/worldcup/football5.gif','gif',1,'c377de39abfdb7c0f73640f63a4892bf'),(6,'/wall/themes/meepo/assets/images/shake/worldcup/football6.gif','gif',1,'32752496889ac4ee5b86137d4a8cfbd2'),(7,'/wall/themes/meepo/assets/images/shake/worldcup/football7.gif','gif',1,'c7e222195ede65f1717a2183f69ec09f'),(8,'/wall/themes/meepo/assets/images/shake/worldcup/football8.gif','gif',1,'1c3e027d25b720a4368a39c6957b2ab8'),(9,'/wall/themes/meepo/assets/images/shake/worldcup/football9.gif','gif',1,'e7f176ee2343b1f99873d833fea8fb8a'),(10,'/wall/themes/meepo/assets/images/shake/worldcup/football10.gif','gif',1,'8b08e371aa58e2b65f879ad9fc590b02'),(11,'/wall/themes/meepo/assets/images/shake/worldcup/bg.mp4','mp4',1,'a87fbbee00734ea2f134c9d87f936207'),(12,'/mobile/template/app/images/shake/shake2.png','png',1,'0342d812ad0da3bbcea87abaf93617d9'),(13,'/Modules/Choujiang/templates/mobile/guaguaka/assets/images/icon.png','png',1,'0e491cae8fd78b87542c36eba4bbf35c'),(14,'/wall/themes/meepo/assets/images/shake/pig/pig.gif','gif',1,'874636879e8a6062e7321987fcd77d38'),(15,'/wall/themes/meepo/assets/images/shake/pig/shake0.png','png',1,'7e7235957843aa42b10d312ceb05f265');
/*!40000 ALTER TABLE `weixin_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_background`
--

DROP TABLE IF EXISTS `weixin_background`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_background` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attachmentid` int(11) DEFAULT NULL COMMENT '背景图id',
  `name` varchar(32) DEFAULT NULL COMMENT '名称',
  `plugname` varchar(32) DEFAULT NULL COMMENT '关联的组件名',
  `bgtype` tinyint(1) DEFAULT NULL COMMENT '1图片2视频',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_background`
--

LOCK TABLES `weixin_background` WRITE;
/*!40000 ALTER TABLE `weixin_background` DISABLE KEYS */;
INSERT INTO `weixin_background` VALUES (1,NULL,'签到墙背景','qdq',1),(2,NULL,'微信上墙背景','wall',1),(3,NULL,'对对碰背景','ddp',1),(4,NULL,'投票背景','vote',1),(5,NULL,'幸运手机号背景','xysjh',1),(6,NULL,'幸运号码背景','xyh',1),(7,NULL,'相册背景','xiangce',1),(8,NULL,'开幕墙背景','kaimu',1),(9,NULL,'闭幕墙背景','bimu',1),(10,NULL,'红包雨背景','redpacket',1),(11,NULL,'摇大奖背景','ydj',1),(12,NULL,'导入抽奖背景图','importlottery',1),(13,NULL,'3D签到背景图','threedimensionalsign',1);
/*!40000 ALTER TABLE `weixin_background` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_bimu_config`
--

DROP TABLE IF EXISTS `weixin_bimu_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_bimu_config` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `imagepath` int(11) DEFAULT NULL COMMENT '闭幕墙鸣谢图id',
  `fullscreen` tinyint(1) DEFAULT '1' COMMENT '1表示居中2表示全屏',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='闭幕墙配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_bimu_config`
--

LOCK TABLES `weixin_bimu_config` WRITE;
/*!40000 ALTER TABLE `weixin_bimu_config` DISABLE KEYS */;
INSERT INTO `weixin_bimu_config` VALUES (1,0,1);
/*!40000 ALTER TABLE `weixin_bimu_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_choujiang_config`
--

DROP TABLE IF EXISTS `weixin_choujiang_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_choujiang_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `themeid` int(11) DEFAULT NULL COMMENT '主题id',
  `showleftnum` tinyint(1) NOT NULL DEFAULT '2' COMMENT '1表示显示剩余数量2表示不显示剩余数量',
  `defaultnum` tinyint(3) DEFAULT NULL COMMENT '默认的抽取次数',
  `description` text COMMENT '游戏说明',
  `created_at` int(11) DEFAULT NULL COMMENT '创建时间',
  `started_at` int(11) DEFAULT NULL COMMENT '开始时间',
  `ended_at` int(11) DEFAULT NULL COMMENT '结束时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='抽奖配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_choujiang_config`
--

LOCK TABLES `weixin_choujiang_config` WRITE;
/*!40000 ALTER TABLE `weixin_choujiang_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_choujiang_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_choujiang_themes`
--

DROP TABLE IF EXISTS `weixin_choujiang_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_choujiang_themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `themepath` varchar(255) DEFAULT NULL COMMENT '主题路径',
  `themename` varchar(255) DEFAULT NULL COMMENT '主题名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='抽奖主题';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_choujiang_themes`
--

LOCK TABLES `weixin_choujiang_themes` WRITE;
/*!40000 ALTER TABLE `weixin_choujiang_themes` DISABLE KEYS */;
INSERT INTO `weixin_choujiang_themes` VALUES (1,'guaguaka','刮刮卡');
/*!40000 ALTER TABLE `weixin_choujiang_themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_choujiang_users`
--

DROP TABLE IF EXISTS `weixin_choujiang_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_choujiang_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `choujiangid` int(11) DEFAULT NULL COMMENT '抽奖配置id',
  `userid` int(11) DEFAULT NULL,
  `cjtimes` tinyint(3) DEFAULT NULL COMMENT '抽取的次数',
  `lefttimes` tinyint(3) DEFAULT NULL COMMENT '剩余次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='设置每个人可以抽几次奖，如果没有记录则使用抽奖配置中的默认次数';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_choujiang_users`
--

LOCK TABLES `weixin_choujiang_users` WRITE;
/*!40000 ALTER TABLE `weixin_choujiang_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_choujiang_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_cookie`
--

DROP TABLE IF EXISTS `weixin_cookie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_cookie` (
  `cookie` text NOT NULL,
  `cookies` text NOT NULL,
  `token` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_cookie`
--

LOCK TABLES `weixin_cookie` WRITE;
/*!40000 ALTER TABLE `weixin_cookie` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_cookie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_danmu_config`
--

DROP TABLE IF EXISTS `weixin_danmu_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_danmu_config` (
  `id` int(11) NOT NULL COMMENT 'id',
  `danmuswitch` tinyint(1) DEFAULT '1' COMMENT '1表示关2表示开',
  `textcolor` varchar(7) DEFAULT NULL COMMENT '16进制颜色值',
  `looptime` int(3) DEFAULT NULL COMMENT '消息显示的时间间隔，单位是秒',
  `isloop` tinyint(1) DEFAULT NULL COMMENT '1表示不循环2表示循环',
  `historynum` int(3) DEFAULT NULL COMMENT '循环时使用的历史记录条数',
  `positionmode` tinyint(1) DEFAULT NULL COMMENT '1表示上三分之一2表示中间三分之一3表示下三分之一4表示全屏随机',
  `showname` tinyint(1) DEFAULT NULL COMMENT '1不显示昵称2显示昵称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_danmu_config`
--

LOCK TABLES `weixin_danmu_config` WRITE;
/*!40000 ALTER TABLE `weixin_danmu_config` DISABLE KEYS */;
INSERT INTO `weixin_danmu_config` VALUES (1,2,'#b7e692',3,2,30,4,2);
/*!40000 ALTER TABLE `weixin_danmu_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_flag`
--

DROP TABLE IF EXISTS `weixin_flag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_flag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(255) NOT NULL COMMENT 'openid',
  `flag` int(11) DEFAULT NULL COMMENT '1表示未签到2表示签到成功',
  `nickname` varchar(255) DEFAULT NULL COMMENT '微信昵称',
  `avatar` text COMMENT '微信头像',
  `sex` varchar(255) DEFAULT NULL COMMENT '性别',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1正常2禁用（禁用状态不能使用任何功能）',
  `datetime` int(10) DEFAULT NULL,
  `fromtype` varchar(25) DEFAULT NULL COMMENT '签到来源weixin',
  `rentopenid` varchar(28) DEFAULT NULL COMMENT '借用来openid',
  `signname` varchar(32) NOT NULL DEFAULT '' COMMENT '签到记录的姓名',
  `phone` varchar(11) DEFAULT NULL COMMENT '电话',
  `signorder` int(11) DEFAULT NULL COMMENT '签到顺序',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `rentopenid` (`rentopenid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='用户微信信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_flag`
--

LOCK TABLES `weixin_flag` WRITE;
/*!40000 ALTER TABLE `weixin_flag` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_flag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_flag_config`
--

DROP TABLE IF EXISTS `weixin_flag_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_flag_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reserved_infomation_match` tinyint(1) DEFAULT '1' COMMENT '1表示不完全匹配2表示完全匹配',
  `reserved_infomation_verify` tinyint(1) DEFAULT '1' COMMENT '1表示通过2表示不通过审核',
  `reserved_infomation_csv_attachmentid` int(11) DEFAULT '0' COMMENT '上传的csv位置',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='签到用户配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_flag_config`
--

LOCK TABLES `weixin_flag_config` WRITE;
/*!40000 ALTER TABLE `weixin_flag_config` DISABLE KEYS */;
INSERT INTO `weixin_flag_config` VALUES (1,1,1,0);
/*!40000 ALTER TABLE `weixin_flag_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_flag_extention_column_type`
--

DROP TABLE IF EXISTS `weixin_flag_extention_column_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_flag_extention_column_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordernum` int(11) DEFAULT NULL COMMENT '排序号',
  `coltype` varchar(20) DEFAULT NULL COMMENT '字段类型',
  `title` varchar(50) DEFAULT NULL COMMENT '字段名称',
  `placeholder` varchar(255) DEFAULT NULL COMMENT '占位内容',
  `options` text COMMENT '选项内容',
  `defaultvalue` text COMMENT '默认内容',
  `ismust` tinyint(1) DEFAULT NULL COMMENT '1不是必填2必填',
  `created_at` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_flag_extention_column_type`
--

LOCK TABLES `weixin_flag_extention_column_type` WRITE;
/*!40000 ALTER TABLE `weixin_flag_extention_column_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_flag_extention_column_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_flag_extention_data`
--

DROP TABLE IF EXISTS `weixin_flag_extention_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_flag_extention_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL COMMENT '用户id',
  `datastr` text COMMENT '内容',
  `created_at` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userid_index` (`userid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_flag_extention_data`
--

LOCK TABLES `weixin_flag_extention_data` WRITE;
/*!40000 ALTER TABLE `weixin_flag_extention_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_flag_extention_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_flag_reserved_infomation`
--

DROP TABLE IF EXISTS `weixin_flag_reserved_infomation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_flag_reserved_infomation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `realname` varchar(30) DEFAULT NULL COMMENT '姓名',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `info` varchar(255) DEFAULT NULL COMMENT '预留信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='签到用户预留信息表，在用户签到时如果匹配到其中的数据，就会把这个数据显示到用户的签到界面上';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_flag_reserved_infomation`
--

LOCK TABLES `weixin_flag_reserved_infomation` WRITE;
/*!40000 ALTER TABLE `weixin_flag_reserved_infomation` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_flag_reserved_infomation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_game_config`
--

DROP TABLE IF EXISTS `weixin_game_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_game_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `toprank` int(5) DEFAULT '3' COMMENT '前几名获奖',
  `winagain` tinyint(1) DEFAULT '1' COMMENT '1表示不能重复2表示可以重复获奖，默认是1',
  `status` tinyint(1) DEFAULT '1' COMMENT '1表示未开始，2进行中，3表示结束',
  `showtype` varchar(32) DEFAULT NULL COMMENT '默认是nickname',
  `themeid` int(11) DEFAULT NULL COMMENT '主题id',
  `themeconfig` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='摇一摇游戏配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_game_config`
--

LOCK TABLES `weixin_game_config` WRITE;
/*!40000 ALTER TABLE `weixin_game_config` DISABLE KEYS */;
INSERT INTO `weixin_game_config` VALUES (1,10,1,1,'nickname',6,''),(2,10,1,1,'nickname',1,''),(3,10,1,1,'nickname',2,''),(4,10,1,1,'nickname',3,''),(5,10,1,1,'nickname',4,''),(6,10,1,1,'nickname',5,''),(7,10,1,1,'nickname',7,''),(8,10,1,1,'nickname',8,''),(9,10,1,1,'nickname',9,''),(10,10,1,1,'nickname',10,''),(11,10,1,1,'nickname',11,'');
/*!40000 ALTER TABLE `weixin_game_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_game_records`
--

DROP TABLE IF EXISTS `weixin_game_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_game_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `gameid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='游戏记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_game_records`
--

LOCK TABLES `weixin_game_records` WRITE;
/*!40000 ALTER TABLE `weixin_game_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_game_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_game_themes`
--

DROP TABLE IF EXISTS `weixin_game_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_game_themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `themename` varchar(32) DEFAULT NULL COMMENT '主题名称',
  `themepath` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_game_themes`
--

LOCK TABLES `weixin_game_themes` WRITE;
/*!40000 ALTER TABLE `weixin_game_themes` DISABLE KEYS */;
INSERT INTO `weixin_game_themes` VALUES (1,'默认汽车主题','Racing'),(2,'猴子爬树','Monkey'),(3,'数钱游戏','Money'),(4,'金猪送福','Pig'),(5,'赛跑','Runner'),(6,'赛龙舟','DragonBoat'),(7,'赛车','Car'),(8,'赛马','Horse'),(9,'游艇','Yacht'),(10,'丘比特之箭','Qiubite'),(11,'欢乐六一','Happy61');
/*!40000 ALTER TABLE `weixin_game_themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_importlottery`
--

DROP TABLE IF EXISTS `weixin_importlottery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_importlottery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `col1` varchar(255) DEFAULT NULL,
  `col2` varchar(255) DEFAULT NULL,
  `col3` varchar(255) DEFAULT NULL,
  `imgid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_importlottery`
--

LOCK TABLES `weixin_importlottery` WRITE;
/*!40000 ALTER TABLE `weixin_importlottery` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_importlottery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_importlotterycolumns`
--

DROP TABLE IF EXISTS `weixin_importlotterycolumns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_importlotterycolumns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `col_name1` varchar(255) DEFAULT NULL,
  `col_name2` varchar(255) DEFAULT NULL,
  `col_name3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_importlotterycolumns`
--

LOCK TABLES `weixin_importlotterycolumns` WRITE;
/*!40000 ALTER TABLE `weixin_importlotterycolumns` DISABLE KEYS */;
INSERT INTO `weixin_importlotterycolumns` VALUES (1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `weixin_importlotterycolumns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_kaimu_config`
--

DROP TABLE IF EXISTS `weixin_kaimu_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_kaimu_config` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `imagepath` int(11) DEFAULT NULL COMMENT '开幕墙图片地址id',
  `fullscreen` tinyint(1) DEFAULT '1' COMMENT '1表示居中2表示全屏',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='开幕墙配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_kaimu_config`
--

LOCK TABLES `weixin_kaimu_config` WRITE;
/*!40000 ALTER TABLE `weixin_kaimu_config` DISABLE KEYS */;
INSERT INTO `weixin_kaimu_config` VALUES (1,0,1);
/*!40000 ALTER TABLE `weixin_kaimu_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_lottery_config`
--

DROP TABLE IF EXISTS `weixin_lottery_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_lottery_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL COMMENT '主题名称',
  `themeid` int(11) DEFAULT NULL COMMENT '主题id',
  `created_at` int(11) DEFAULT NULL COMMENT '创建时间',
  `winagain` tinyint(1) DEFAULT NULL COMMENT '之前得过奖的还能再次参与 1表示不可以，2表示可以',
  `showtype` varchar(255) DEFAULT '' COMMENT '默认是nickname',
  `themeconfig` text COMMENT '主题的配置',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='抽奖配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_lottery_config`
--

LOCK TABLES `weixin_lottery_config` WRITE;
/*!40000 ALTER TABLE `weixin_lottery_config` DISABLE KEYS */;
INSERT INTO `weixin_lottery_config` VALUES (1,'第1轮活动',1,1,1,'nickname',''),(2,'第2轮活动',2,1,1,'nickname',''),(3,'第3轮活动',3,1,1,'nickname','');
/*!40000 ALTER TABLE `weixin_lottery_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_lottery_themes`
--

DROP TABLE IF EXISTS `weixin_lottery_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_lottery_themes` (
  `id` int(11) NOT NULL,
  `themename` varchar(255) DEFAULT NULL COMMENT '主题名称',
  `themepath` varchar(255) DEFAULT NULL COMMENT '主题文件存放的目录',
  `created_at` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_lottery_themes`
--

LOCK TABLES `weixin_lottery_themes` WRITE;
/*!40000 ALTER TABLE `weixin_lottery_themes` DISABLE KEYS */;
INSERT INTO `weixin_lottery_themes` VALUES (1,'3D抽奖','ThreeDimensional','1'),(2,'砸金蛋','Zjd','2'),(3,'抽奖箱','Cjx','3');
/*!40000 ALTER TABLE `weixin_lottery_themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_menu`
--

DROP TABLE IF EXISTS `weixin_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `icon` int(11) DEFAULT NULL COMMENT '按钮图标',
  `link` text COMMENT '链接',
  `ordernum` int(11) DEFAULT NULL COMMENT '排序',
  `type` tinyint(1) DEFAULT '1' COMMENT '1手机端2pc端',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_menu`
--

LOCK TABLES `weixin_menu` WRITE;
/*!40000 ALTER TABLE `weixin_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_music`
--

DROP TABLE IF EXISTS `weixin_music`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_music` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bgmusic` int(11) DEFAULT NULL COMMENT '背景音乐id',
  `bgmusicstatus` tinyint(1) DEFAULT NULL COMMENT '1开2关',
  `name` varchar(32) DEFAULT NULL COMMENT '名称',
  `plugname` varchar(32) DEFAULT NULL COMMENT '关联的组件名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_music`
--

LOCK TABLES `weixin_music` WRITE;
/*!40000 ALTER TABLE `weixin_music` DISABLE KEYS */;
INSERT INTO `weixin_music` VALUES (1,NULL,2,'签到墙背景乐','qdq'),(2,NULL,2,'对对碰背景乐','ddp'),(3,NULL,2,'投票背景乐','vote'),(4,NULL,2,'幸运手机号背景乐','xysjh'),(5,NULL,2,'幸运号码背景乐','xyh'),(6,NULL,2,'3D签到背景乐','threedimensionalsign'),(7,NULL,2,'微信上墙背景乐','wall'),(8,NULL,2,'相册背景乐','xiangce'),(9,NULL,2,'开幕墙背景乐','kaimu'),(10,NULL,2,'闭幕墙背景乐','bimu'),(11,NULL,2,'红包雨背景乐','redpacket'),(12,NULL,2,'摇大奖树背景乐','ydj'),(13,NULL,2,'导入抽奖','importlottery');
/*!40000 ALTER TABLE `weixin_music` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_pashu_config`
--

DROP TABLE IF EXISTS `weixin_pashu_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_pashu_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `times` int(11) NOT NULL DEFAULT '0',
  `toprank` int(5) DEFAULT '3' COMMENT '前几名获奖',
  `winningagain` tinyint(1) DEFAULT '1' COMMENT '1表示不能重复2表示可以重复获奖，默认是1',
  `status` tinyint(1) DEFAULT '1' COMMENT '1表示未开始，2进行中，3表示结束',
  `maxplayers` int(11) unsigned DEFAULT '200' COMMENT '最大参与人数，默认200',
  `showstyle` tinyint(1) DEFAULT '1' COMMENT '1昵称2姓名3手机号',
  `currentshow` tinyint(1) DEFAULT '1' COMMENT '1不是当前活动2当前活动',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='猴子爬树配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_pashu_config`
--

LOCK TABLES `weixin_pashu_config` WRITE;
/*!40000 ALTER TABLE `weixin_pashu_config` DISABLE KEYS */;
INSERT INTO `weixin_pashu_config` VALUES (1,100,3,1,1,200,1,1),(2,100,3,1,1,200,1,2),(3,100,3,1,1,200,1,2),(4,100,3,1,1,200,1,2),(5,100,3,1,1,200,1,2),(6,100,3,1,1,200,1,2),(7,100,3,1,1,200,1,2),(8,100,3,1,1,200,1,2),(9,100,3,1,1,200,1,2),(10,100,3,1,1,200,1,2);
/*!40000 ALTER TABLE `weixin_pashu_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_pashu_record`
--

DROP TABLE IF EXISTS `weixin_pashu_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_pashu_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `point` int(11) DEFAULT NULL COMMENT '数量',
  `openid` varchar(255) DEFAULT NULL COMMENT 'openid',
  `configid` int(11) DEFAULT NULL COMMENT '配置id',
  `iswinner` tinyint(1) DEFAULT NULL COMMENT '1不是2是中奖用户',
  PRIMARY KEY (`id`),
  KEY `openid_configid_idx` (`openid`,`configid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='猴子爬树游戏记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_pashu_record`
--

LOCK TABLES `weixin_pashu_record` WRITE;
/*!40000 ALTER TABLE `weixin_pashu_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_pashu_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_plugs`
--

DROP TABLE IF EXISTS `weixin_plugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_plugs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '模块名',
  `title` varchar(255) DEFAULT NULL COMMENT '模块中文名',
  `switch` tinyint(1) unsigned zerofill NOT NULL DEFAULT '0' COMMENT '1表示开2表示关',
  `url` varchar(255) DEFAULT NULL COMMENT 'url',
  `img` varchar(255) DEFAULT NULL COMMENT '图标',
  `ordernum` tinyint(3) unsigned zerofill DEFAULT '000' COMMENT '排序号',
  `choujiang` tinyint(1) unsigned zerofill DEFAULT '0' COMMENT '0表示不是抽奖项目1表示不能重复中奖，2表示可以重复中奖',
  `hotkey` varchar(10) DEFAULT NULL COMMENT '快捷键',
  `ismodule` tinyint(1) DEFAULT '2' COMMENT '1表示是组件2表示不是，默认为2',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_plugs`
--

LOCK TABLES `weixin_plugs` WRITE;
/*!40000 ALTER TABLE `weixin_plugs` DISABLE KEYS */;
INSERT INTO `weixin_plugs` VALUES (1,'qdq','签到墙',1,'/wall/index.php','themes/meepo/assets/images/icon/ico005.png',001,0,'ctrl+1',2),(2,'ddp','对对碰',1,'/wall/ddp.php','themes/meepo/assets/images/icon/ico006.png',010,0,'ctrl+8',2),(3,'vote','投票',1,'/wall/vote.php','themes/meepo/assets/images/icon/ico004.png',005,0,'ctrl+5',2),(4,'xysjh','幸运手机号',1,'/wall/xysjh.php','themes/meepo/assets/images/icon/ico019.png',008,0,'ctrl+7',2),(5,'xyh','幸运号码',1,'/wall/xyh.php','themes/meepo/assets/images/icon/ico016.png',007,0,'ctrl+6',2),(6,'threedimensionalsign','3D签到',1,'/wall/3dsign.php','themes/meepo/assets/images/icon/ico013.png',002,0,'ctrl+2',2),(7,'wall','微信上墙',1,'/wall/wall.php','themes/meepo/assets/images/icon/ico009.png',003,0,'ctrl+3',2),(8,'xiangce','相册',1,'/wall/xiangce.php','themes/meepo/assets/images/icon/ico003.png',012,0,'ctrl+9',2),(9,'kaimu','开幕墙',1,'/wall/kaimu.php','themes/meepo/assets/images/icon/ico007.png',014,0,'ctrl+k',2),(10,'bimu','闭幕墙',1,'/wall/bimu.php','themes/meepo/assets/images/icon/ico014.png',015,0,'ctrl+b',2),(11,'redpacket','红包雨',2,'/wall/redpacket.php','themes/meepo/assets/images/icon/redpack3.png',016,0,'ctrl+r',2),(12,'ydj','摇大奖',1,NULL,NULL,020,1,'ctrl+y',1),(13,'choujiang','手机端抽奖',1,NULL,NULL,021,1,'',1),(14,'importlottery','导入抽奖',1,NULL,NULL,022,1,'',1),(15,'lottery','抽奖',1,NULL,NULL,023,1,NULL,1),(16,'game','游戏',1,NULL,NULL,024,1,NULL,1);
/*!40000 ALTER TABLE `weixin_plugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_prizes`
--

DROP TABLE IF EXISTS `weixin_prizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_prizes` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `prizename` varchar(255) DEFAULT NULL COMMENT '奖品名称',
  `type` tinyint(1) DEFAULT NULL COMMENT '奖品类型1普通奖品2微信卡券3微信红包4微信零钱5虚拟卡密',
  `num` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '奖品数量',
  `freezenum` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '冻结的数量',
  `leftnum` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '剩余数量（不包含冻结的数量）',
  `prizedata` text COMMENT '序列化的奖品数据',
  `plugname` varchar(64) DEFAULT NULL COMMENT '组件名称',
  `activityid` int(11) unsigned DEFAULT '0' COMMENT '活动编号，没有就是0，有就是id',
  `isdel` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1表示正常2表示已删除',
  `rate` int(11) unsigned NOT NULL DEFAULT '1000000' COMMENT '中奖概率，百万分之一',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='奖品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_prizes`
--

LOCK TABLES `weixin_prizes` WRITE;
/*!40000 ALTER TABLE `weixin_prizes` DISABLE KEYS */;
INSERT INTO `weixin_prizes` VALUES (1,'奖品1',1,10,0,10,'a:1:{s:7:\"imageid\";i:0;}','ydj',1,1,1000000),(2,'奖品2',1,10,0,10,'a:1:{s:7:\"imageid\";i:0;}','ydj',1,1,1000000),(3,'奖品3',1,10,0,10,'a:1:{s:7:\"imageid\";i:0;}','ydj',1,1,1000000),(4,'奖品1',1,10,0,10,'a:1:{s:7:\"imageid\";i:0;}','ydj',2,1,1000000),(5,'奖品2',1,10,0,10,'a:1:{s:7:\"imageid\";i:0;}','ydj',2,1,1000000),(6,'奖品3',1,10,0,10,'a:1:{s:7:\"imageid\";i:0;}','ydj',2,1,1000000),(7,'奖品1',1,10,0,10,'a:1:{s:7:\"imageid\";i:0;}','ydj',3,1,1000000),(8,'奖品2',1,10,0,10,'a:1:{s:7:\"imageid\";i:0;}','ydj',3,1,1000000),(9,'奖品3',1,10,0,10,'a:1:{s:7:\"imageid\";i:0;}','ydj',3,1,1000000),(10,'奖品1',1,100,0,100,'a:1:{s:7:\"imageid\";i:0;}','importlottery',1,1,1000000),(11,'奖品2',1,100,0,100,'a:1:{s:7:\"imageid\";i:0;}','importlottery',1,1,1000000),(12,'奖品3',1,100,0,100,'a:1:{s:7:\"imageid\";i:0;}','importlottery',1,1,1000000),(13,'一等奖',1,100,0,100,'a:1:{s:7:\"imageid\";i:0;}','lottery',1,1,1000000),(14,'二等奖',1,100,0,100,'a:1:{s:7:\"imageid\";i:0;}','lottery',1,1,1000000),(15,'三等奖',1,100,0,100,'a:1:{s:7:\"imageid\";i:0;}','lottery',1,1,1000000),(16,'一等奖',1,100,0,100,'a:1:{s:7:\"imageid\";i:0;}','lottery',2,1,1000000),(17,'二等奖',1,100,0,100,'a:1:{s:7:\"imageid\";i:0;}','lottery',2,1,1000000),(18,'三等奖',1,100,0,100,'a:1:{s:7:\"imageid\";i:0;}','lottery',2,1,1000000),(19,'一等奖',1,100,0,100,'a:1:{s:7:\"imageid\";i:0;}','lottery',3,1,1000000),(20,'二等奖',1,100,0,100,'a:1:{s:7:\"imageid\";i:0;}','lottery',3,1,1000000),(21,'三等奖',1,100,0,100,'a:1:{s:7:\"imageid\";i:0;}','lottery',3,1,1000000);
/*!40000 ALTER TABLE `weixin_prizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_redpacket_config`
--

DROP TABLE IF EXISTS `weixin_redpacket_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_redpacket_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule` text COMMENT '抢红包规则',
  `tips` text COMMENT '提示语',
  `sendname` varchar(32) DEFAULT NULL COMMENT '红包发送者名称',
  `wishing` varchar(128) DEFAULT NULL COMMENT '祝福语',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='红包配置信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_redpacket_config`
--

LOCK TABLES `weixin_redpacket_config` WRITE;
/*!40000 ALTER TABLE `weixin_redpacket_config` DISABLE KEYS */;
INSERT INTO `weixin_redpacket_config` VALUES (1,'1.用户打开微信扫描大屏幕上的二维码进入等待抢红包页面\n2.主持人说开始后，大屏幕和手机页面同时落下红包雨\n3.用户随机选择落下的红包，并拆开红包。\n4.如果倒计时还在继续，那么无论用户是否抢到了，都可以继续抢 直到倒计时完成。','大屏幕倒计时开始，\n红包将从大屏幕降落到手机，此时\n手指戳红包即可参与\n抢红包游戏','','');
/*!40000 ALTER TABLE `weixin_redpacket_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_redpacket_order_return`
--

DROP TABLE IF EXISTS `weixin_redpacket_order_return`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_redpacket_order_return` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_code` varchar(16) DEFAULT NULL COMMENT '返回状态吗',
  `return_msg` varchar(128) DEFAULT NULL COMMENT '返回信息表',
  `sign` varchar(32) DEFAULT NULL COMMENT '签名信息',
  `result_code` varchar(16) DEFAULT NULL COMMENT '业务结果',
  `err_code` varchar(32) DEFAULT NULL COMMENT '错误代码',
  `err_code_des` varchar(128) DEFAULT NULL COMMENT '错误代码描述',
  `mch_billno` varchar(28) DEFAULT NULL COMMENT '商户订单号',
  `mch_id` varchar(32) DEFAULT NULL COMMENT '商户号',
  `wxappid` varchar(32) DEFAULT NULL COMMENT '公众号appid',
  `re_openid` varchar(32) DEFAULT NULL COMMENT '收红包用户的openid',
  `total_amount` int(11) DEFAULT NULL COMMENT '付款金额',
  `send_listid` varchar(32) DEFAULT NULL COMMENT '微信单号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='发红包返回信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_redpacket_order_return`
--

LOCK TABLES `weixin_redpacket_order_return` WRITE;
/*!40000 ALTER TABLE `weixin_redpacket_order_return` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_redpacket_order_return` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_redpacket_orders`
--

DROP TABLE IF EXISTS `weixin_redpacket_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_redpacket_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `mch_billno` varchar(28) DEFAULT NULL COMMENT '商户订单号',
  `mch_id` varchar(32) DEFAULT NULL COMMENT '商户号',
  `wxappid` varchar(32) DEFAULT NULL COMMENT '公众号appid',
  `send_name` varchar(32) DEFAULT NULL COMMENT '红包发送者名称',
  `re_openid` varchar(32) DEFAULT NULL COMMENT '接受红包的openid',
  `total_num` int(11) DEFAULT '1',
  `wishing` varchar(128) DEFAULT NULL COMMENT '祝福语',
  `client_ip` varchar(15) DEFAULT NULL COMMENT '调用接口机器的ip',
  `act_name` varchar(32) DEFAULT NULL COMMENT '活动名称',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `scene_id` varchar(32) DEFAULT NULL COMMENT '场景id',
  `risk_info` varchar(128) DEFAULT NULL COMMENT '活动信息',
  `consume_mch_id` varchar(32) DEFAULT NULL COMMENT '资金授权商户号',
  `nonce_str` varchar(32) DEFAULT NULL COMMENT '随机字符串',
  `sign` varchar(32) DEFAULT NULL COMMENT '数据签名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='红包订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_redpacket_orders`
--

LOCK TABLES `weixin_redpacket_orders` WRITE;
/*!40000 ALTER TABLE `weixin_redpacket_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_redpacket_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_redpacket_round`
--

DROP TABLE IF EXISTS `weixin_redpacket_round`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_redpacket_round` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) unsigned DEFAULT '1' COMMENT '1未开始2进行中3结束',
  `type` tinyint(1) unsigned DEFAULT '1' COMMENT '1普通红包2随机红包',
  `amount` int(8) unsigned DEFAULT '0' COMMENT '红包金额 单位是分',
  `num` int(4) unsigned DEFAULT '1' COMMENT '红包个数大于1',
  `numperperson` tinyint(3) unsigned DEFAULT '1' COMMENT '每个用户此轮可抢的红包数量，默认为1个',
  `chance` int(4) unsigned DEFAULT '0' COMMENT '红包获得概率，单位是千分之1',
  `lefttime` int(11) unsigned DEFAULT '30' COMMENT '活动持续时间，单位是秒',
  `minamount` int(8) unsigned DEFAULT '0' COMMENT '随机红包最小金额大于100，单位是分',
  `maxamount` int(8) unsigned DEFAULT '0' COMMENT '随机红包的最大金额',
  `started_at` int(11) DEFAULT NULL COMMENT '轮次开始时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='红包轮次配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_redpacket_round`
--

LOCK TABLES `weixin_redpacket_round` WRITE;
/*!40000 ALTER TABLE `weixin_redpacket_round` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_redpacket_round` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_redpacket_users`
--

DROP TABLE IF EXISTS `weixin_redpacket_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_redpacket_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL COMMENT '用户id',
  `roundid` int(11) DEFAULT NULL COMMENT '轮次id',
  `amount` int(11) DEFAULT NULL COMMENT '红包金额，单位是分',
  `created_at` int(11) DEFAULT NULL COMMENT '红包领取时间',
  `updated_at` int(11) DEFAULT NULL COMMENT '发放完成时间',
  `status` tinyint(1) DEFAULT NULL COMMENT '1表示未发2表示发放中3已发4发放失败',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='红包雨中奖用户数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_redpacket_users`
--

LOCK TABLES `weixin_redpacket_users` WRITE;
/*!40000 ALTER TABLE `weixin_redpacket_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_redpacket_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_sessions`
--

DROP TABLE IF EXISTS `weixin_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(15) NOT NULL DEFAULT '0',
  `user_agent` varchar(200) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_sessions`
--

LOCK TABLES `weixin_sessions` WRITE;
/*!40000 ALTER TABLE `weixin_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_shake_config`
--

DROP TABLE IF EXISTS `weixin_shake_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_shake_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `duration` int(11) NOT NULL DEFAULT '1' COMMENT '持续条件（次/秒）',
  `durationtype` tinyint(1) DEFAULT '1' COMMENT '1表示按时间，2表示按次数',
  `toprank` int(5) DEFAULT '3' COMMENT '前几名获奖',
  `winningagain` tinyint(1) DEFAULT '1' COMMENT '1表示不能重复2表示可以重复获奖，默认是1',
  `status` tinyint(1) DEFAULT '1' COMMENT '1表示未开始，2进行中，3表示结束',
  `maxplayers` int(11) unsigned DEFAULT '200' COMMENT '最大参与人数，默认200',
  `showstyle` tinyint(1) DEFAULT '1' COMMENT '1昵称2姓名3手机号',
  `currentshow` tinyint(1) DEFAULT '1' COMMENT '1不是当前活动2当前活动',
  `themeid` int(11) DEFAULT NULL COMMENT '主题id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='摇一摇游戏配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_shake_config`
--

LOCK TABLES `weixin_shake_config` WRITE;
/*!40000 ALTER TABLE `weixin_shake_config` DISABLE KEYS */;
INSERT INTO `weixin_shake_config` VALUES (1,100,2,3,1,1,200,1,2,1),(2,100,2,3,1,1,200,1,1,2),(3,100,2,3,1,1,200,1,1,3),(4,100,2,3,1,1,200,1,1,1),(5,100,2,3,1,1,200,1,1,2),(6,100,2,3,1,1,200,1,1,3),(7,100,2,3,1,1,200,1,1,1),(8,100,2,3,1,1,200,1,1,2),(9,100,2,3,1,1,200,1,1,3),(10,100,2,3,1,1,200,1,1,1);
/*!40000 ALTER TABLE `weixin_shake_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_shake_record`
--

DROP TABLE IF EXISTS `weixin_shake_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_shake_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `point` int(11) DEFAULT NULL COMMENT '数量',
  `userid` int(11) DEFAULT NULL COMMENT '用户id',
  `configid` int(11) DEFAULT NULL COMMENT '配置id',
  `iswinner` tinyint(1) DEFAULT NULL COMMENT '1不是2是中奖用户',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userid_configid_index` (`userid`,`configid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='摇一摇游戏记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_shake_record`
--

LOCK TABLES `weixin_shake_record` WRITE;
/*!40000 ALTER TABLE `weixin_shake_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_shake_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_shake_themes`
--

DROP TABLE IF EXISTS `weixin_shake_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_shake_themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `themename` varchar(32) DEFAULT NULL COMMENT '主题名称',
  `themedata` text COMMENT '主题的数据',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_shake_themes`
--

LOCK TABLES `weixin_shake_themes` WRITE;
/*!40000 ALTER TABLE `weixin_shake_themes` DISABLE KEYS */;
INSERT INTO `weixin_shake_themes` VALUES (1,'默认横向汽车主题','a:2:{s:12:\"ishorizontal\";s:1:\"1\";s:4:\"tips\";a:8:{i:0;s:12:\"再大力！\";i:1;s:22:\"再大力,再大力！\";i:2;s:32:\"再大力,再大力,再大力！\";i:3;s:15:\"摇，大力摇\";i:4;s:24:\"快点摇啊，别停！\";i:5;s:24:\"摇啊，摇啊，摇啊\";i:6;s:45:\"小心手机，别飞出去伤到花花草草\";i:7;s:18:\"看灰机～～～\";}}'),(2,'默认纵向气球主题','a:2:{s:12:\"ishorizontal\";s:1:\"2\";s:4:\"tips\";a:8:{i:0;s:12:\"再大力！\";i:1;s:22:\"再大力,再大力！\";i:2;s:32:\"再大力,再大力,再大力！\";i:3;s:15:\"摇，大力摇\";i:4;s:24:\"快点摇啊，别停！\";i:5;s:24:\"摇啊，摇啊，摇啊\";i:6;s:45:\"小心手机，别飞出去伤到花花草草\";i:7;s:18:\"看灰机～～～\";}}'),(3,'横向足球主题','a:18:{s:12:\"ishorizontal\";i:1;s:8:\"avatar_1\";i:1;s:8:\"avatar_2\";i:2;s:8:\"avatar_3\";i:3;s:8:\"avatar_4\";i:4;s:8:\"avatar_5\";i:5;s:8:\"avatar_6\";i:6;s:8:\"avatar_7\";i:7;s:8:\"avatar_8\";i:8;s:8:\"avatar_9\";i:9;s:9:\"avatar_10\";i:10;s:9:\"startline\";i:0;s:7:\"endline\";i:0;s:8:\"trackodd\";i:0;s:9:\"trackeven\";i:0;s:2:\"bg\";i:11;s:9:\"mobileimg\";i:12;s:4:\"tips\";a:8:{i:0;s:12:\"再大力！\";i:1;s:22:\"再大力,再大力！\";i:2;s:32:\"再大力,再大力,再大力！\";i:3;s:15:\"摇，大力摇\";i:4;s:24:\"快点摇啊，别停！\";i:5;s:24:\"摇啊，摇啊，摇啊\";i:6;s:45:\"小心手机，别飞出去伤到花花草草\";i:7;s:18:\"看灰机～～～\";}}'),(4,'猪年主题','a:18:{s:8:\"avatar_1\";s:2:\"14\";s:8:\"avatar_2\";s:2:\"14\";s:8:\"avatar_3\";s:2:\"14\";s:8:\"avatar_4\";s:2:\"14\";s:8:\"avatar_5\";s:2:\"14\";s:8:\"avatar_6\";s:2:\"14\";s:8:\"avatar_7\";s:2:\"14\";s:8:\"avatar_8\";s:2:\"14\";s:8:\"avatar_9\";s:2:\"14\";s:9:\"avatar_10\";s:2:\"14\";s:9:\"startline\";i:0;s:7:\"endline\";i:0;s:8:\"trackodd\";i:0;s:9:\"trackeven\";i:0;s:2:\"bg\";i:0;s:9:\"mobileimg\";s:2:\"15\";s:12:\"ishorizontal\";s:1:\"1\";s:4:\"tips\";a:8:{i:0;s:12:\"再大力！\";i:1;s:22:\"再大力,再大力！\";i:2;s:32:\"再大力,再大力,再大力！\";i:3;s:15:\"摇，大力摇\";i:4;s:24:\"快点摇啊，别停！\";i:5;s:24:\"摇啊，摇啊，摇啊\";i:6;s:45:\"小心手机，别飞出去伤到花花草草\";i:7;s:18:\"看灰机～～～\";}}');
/*!40000 ALTER TABLE `weixin_shake_themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_shuqian_config`
--

DROP TABLE IF EXISTS `weixin_shuqian_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_shuqian_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `duration` int(4) DEFAULT '30' COMMENT '游戏持续时间',
  `toprank` int(5) DEFAULT '3' COMMENT '前几名获奖',
  `winningagain` tinyint(1) DEFAULT '1' COMMENT '1表示不能重复2表示可以重复获奖，默认是1',
  `status` tinyint(1) DEFAULT '1' COMMENT '1表示未开始，2进行中，3表示结束',
  `maxplayers` int(11) unsigned DEFAULT '200' COMMENT '最大参与人数，默认200',
  `showstyle` tinyint(1) DEFAULT '1' COMMENT '1昵称2姓名3手机号',
  `currentshow` tinyint(1) DEFAULT '1' COMMENT '1不是当前活动2当前活动',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_shuqian_config`
--

LOCK TABLES `weixin_shuqian_config` WRITE;
/*!40000 ALTER TABLE `weixin_shuqian_config` DISABLE KEYS */;
INSERT INTO `weixin_shuqian_config` VALUES (1,30,3,1,1,200,1,1),(2,30,3,1,1,200,1,2),(3,30,3,1,1,200,1,2),(4,30,3,1,1,200,1,2),(5,30,3,1,1,200,1,2),(6,30,3,1,1,200,1,2),(7,30,3,1,1,200,1,2),(8,30,3,1,1,200,1,2),(9,30,3,1,1,200,1,2),(10,30,3,1,1,200,1,2);
/*!40000 ALTER TABLE `weixin_shuqian_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_shuqian_record`
--

DROP TABLE IF EXISTS `weixin_shuqian_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_shuqian_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `point` int(11) DEFAULT NULL COMMENT '数量',
  `openid` varchar(255) DEFAULT NULL COMMENT 'openid',
  `configid` int(11) DEFAULT NULL COMMENT '配置id',
  `iswinner` tinyint(1) DEFAULT NULL COMMENT '1不是2是中奖用户',
  PRIMARY KEY (`id`),
  KEY `openid_configid_idx` (`openid`,`configid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_shuqian_record`
--

LOCK TABLES `weixin_shuqian_record` WRITE;
/*!40000 ALTER TABLE `weixin_shuqian_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_shuqian_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_system_config`
--

DROP TABLE IF EXISTS `weixin_system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_system_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `configkey` varchar(255) DEFAULT NULL COMMENT '配置名称',
  `configvalue` varchar(255) DEFAULT NULL COMMENT '配置值',
  `configname` varchar(255) DEFAULT NULL COMMENT '配置中文名称',
  `configcomment` text COMMENT '配置备注说明',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='系统配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_system_config`
--

LOCK TABLES `weixin_system_config` WRITE;
/*!40000 ALTER TABLE `weixin_system_config` DISABLE KEYS */;
INSERT INTO `weixin_system_config` VALUES (1,'SAVEFILEMODE','file','文件保存模式','file表示文件保存，aliyunoss表示阿里云oss保存图片'),(2,'mobileqiandaobg','0','手机端签到页面背景','手机签到页面的背景图，默认0是现在的星空背景'),(3,'wallnameshowstyle','1','上墙消息显示','1昵称2姓名3手机号'),(4,'signnameshowstyle','1','签到显示','1昵称2姓名3手机号'),(5,'danmushowstyle','1','弹幕显示','1昵称2姓名3手机号'),(6,'ddpshowstyle','1','对对碰显示','1昵称2姓名3手机号'),(7,'qiandaoshenhe','1','签到审核','1表示不需要审核2需要审核'),(8,'qiandaosignname','1','签到填写姓名','1必须2不需要'),(9,'qiandaophone','1','签到填写手机号','1必须2不需要'),(10,'menucolor','#dbb902','菜单颜色','16进制颜色代码'),(11,'showcountsign','2','显示签到人数','1表示不显示签到2显示签到人数3前是通过审核的人数'),(12,'qrcodepos','a:4:{s:1:\"w\";i:90;s:1:\"h\";i:90;s:1:\"x\";i:1802;s:1:\"y\";i:18;}','二维码位置','二维码坐标和大小信息'),(13,'mobilemenufontcolor','#000','签到菜单文字颜色','颜色值,16进制值');
/*!40000 ALTER TABLE `weixin_system_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_threedimensional`
--

DROP TABLE IF EXISTS `weixin_threedimensional`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_threedimensional` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `avatarnum` tinyint(3) unsigned DEFAULT '0',
  `datastr` text,
  `avatarsize` tinyint(3) DEFAULT NULL,
  `avatargap` tinyint(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='3d签到动画设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_threedimensional`
--

LOCK TABLES `weixin_threedimensional` WRITE;
/*!40000 ALTER TABLE `weixin_threedimensional` DISABLE KEYS */;
INSERT INTO `weixin_threedimensional` VALUES (1,30,'#earth|你好2019|#torus',7,15);
/*!40000 ALTER TABLE `weixin_threedimensional` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_user_prize`
--

DROP TABLE IF EXISTS `weixin_user_prize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_user_prize` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prizeid` int(11) DEFAULT NULL COMMENT '奖品id',
  `plugname` varchar(64) DEFAULT NULL COMMENT '组件名称',
  `activityid` int(11) DEFAULT '0' COMMENT '活动轮次id，类似摇一摇的有这个编号，抽奖没有，没有就是0',
  `userid` int(11) DEFAULT NULL COMMENT '用户id',
  `designated` tinyint(1) DEFAULT NULL COMMENT '内定状态1是普通状态2表示内定3表示不会中这个奖',
  `status` tinyint(1) DEFAULT NULL COMMENT '中奖状态1表示未中2表示中奖3表示已发奖4取消',
  `verifycode` varchar(64) DEFAULT NULL COMMENT '兑换码',
  `created_at` int(11) DEFAULT NULL COMMENT '记录创建时间',
  `wintime` int(11) DEFAULT NULL COMMENT '得奖时间',
  `awardtime` int(11) DEFAULT NULL COMMENT '发奖时间',
  `isdel` tinyint(1) DEFAULT NULL COMMENT '1正常2删除',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='获奖名单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_user_prize`
--

LOCK TABLES `weixin_user_prize` WRITE;
/*!40000 ALTER TABLE `weixin_user_prize` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_user_prize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `weixin_view_importlottery`
--

DROP TABLE IF EXISTS `weixin_view_importlottery`;
/*!50001 DROP VIEW IF EXISTS `weixin_view_importlottery`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `weixin_view_importlottery` AS SELECT 
 1 AS `id`,
 1 AS `col1`,
 1 AS `col2`,
 1 AS `col3`,
 1 AS `imgid`,
 1 AS `designated`,
 1 AS `prizeid`,
 1 AS `status`,
 1 AS `verifycode`,
 1 AS `wintime`,
 1 AS `awardtime`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `weixin_view_lottery`
--

DROP TABLE IF EXISTS `weixin_view_lottery`;
/*!50001 DROP VIEW IF EXISTS `weixin_view_lottery`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `weixin_view_lottery` AS SELECT 
 1 AS `id`,
 1 AS `userid`,
 1 AS `nickname`,
 1 AS `avatar`,
 1 AS `signname`,
 1 AS `phone`,
 1 AS `activityid`,
 1 AS `prizeid`,
 1 AS `designated`,
 1 AS `status`,
 1 AS `isdel`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `weixin_vote_config`
--

DROP TABLE IF EXISTS `weixin_vote_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_vote_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `votetitle` varchar(255) DEFAULT NULL COMMENT '投票主题',
  `status` tinyint(1) DEFAULT NULL COMMENT '1开始2结束',
  `created_at` int(11) DEFAULT NULL COMMENT '添加时间',
  `currentshow` tinyint(1) DEFAULT NULL COMMENT '1表示当前大屏幕显示的，2表示不是当前显示的',
  `showtype` int(1) DEFAULT NULL COMMENT '1横向2纵向3图片形式',
  `votenum` int(5) DEFAULT NULL COMMENT '可选几项（多选，默认1是单选）',
  `editable` tinyint(1) DEFAULT NULL COMMENT '1投完之后无法更改，2表示可以修改',
  `refreshtime` tinyint(2) unsigned DEFAULT NULL COMMENT '单位是秒，默认是3秒',
  `votemode` tinyint(1) DEFAULT '1' COMMENT '1表示最大投票数，2表示固定投票数，3表示最少投票数',
  `unit` varchar(255) DEFAULT NULL COMMENT '单位',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_vote_config`
--

LOCK TABLES `weixin_vote_config` WRITE;
/*!40000 ALTER TABLE `weixin_vote_config` DISABLE KEYS */;
INSERT INTO `weixin_vote_config` VALUES (1,'您最喜欢的节目',1,1520227302,1,2,1,1,3,1,'票');
/*!40000 ALTER TABLE `weixin_vote_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_vote_items`
--

DROP TABLE IF EXISTS `weixin_vote_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_vote_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voteconfigid` int(11) DEFAULT NULL COMMENT '投票主题id',
  `voteitem` varchar(255) DEFAULT NULL COMMENT '投票项名称',
  `created_at` int(11) DEFAULT NULL COMMENT '创建时间',
  `imageid` int(11) DEFAULT NULL COMMENT '如果有图片那么图片id',
  `votecount` int(11) DEFAULT '0' COMMENT '获得票数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_vote_items`
--

LOCK TABLES `weixin_vote_items` WRITE;
/*!40000 ALTER TABLE `weixin_vote_items` DISABLE KEYS */;
INSERT INTO `weixin_vote_items` VALUES (1,1,'签到墙',1526136006,NULL,0),(2,1,'微信上墙',1526136018,NULL,0),(3,1,'摇一摇',1526136024,NULL,0),(4,1,'数钱游戏',1526136030,NULL,0),(5,1,'投票',1526136040,NULL,0),(6,1,'抽奖',1526136054,NULL,0),(7,1,'3D抽奖',1526136077,NULL,0),(8,1,'抽奖箱',1526136082,NULL,0),(9,1,'砸金蛋',1526136087,NULL,0),(10,1,'幸运号码',1526136095,NULL,0),(11,1,'幸运手机号',1526136101,NULL,0),(12,1,'相册',1526136110,NULL,0),(13,1,'开幕墙',1526136114,NULL,0),(14,1,'闭幕墙',1526136121,NULL,0);
/*!40000 ALTER TABLE `weixin_vote_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_vote_record`
--

DROP TABLE IF EXISTS `weixin_vote_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_vote_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voteconfigid` int(11) DEFAULT NULL COMMENT '投票主题id',
  `openid` varchar(32) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `voteitemid` int(11) DEFAULT NULL COMMENT '投票项id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_vote_record`
--

LOCK TABLES `weixin_vote_record` WRITE;
/*!40000 ALTER TABLE `weixin_vote_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_vote_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_wall`
--

DROP TABLE IF EXISTS `weixin_wall`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_wall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text,
  `nickname` text,
  `avatar` text,
  `ret` tinyint(1) DEFAULT NULL COMMENT '0待审核1审核通过2审核不通过',
  `fromtype` varchar(255) DEFAULT NULL,
  `image` int(11) DEFAULT NULL COMMENT '图片路径id',
  `datetime` int(10) DEFAULT NULL,
  `openid` varchar(32) DEFAULT NULL COMMENT '发送人的openid',
  `shenhetime` int(11) DEFAULT '0' COMMENT '按照审核的时间顺序来',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_wall`
--

LOCK TABLES `weixin_wall` WRITE;
/*!40000 ALTER TABLE `weixin_wall` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_wall` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_wall_config`
--

DROP TABLE IF EXISTS `weixin_wall_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_wall_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `success` text NOT NULL COMMENT '消息发送成功但是没有审核时的提醒信息，自由手动审核才用这句',
  `shenghe` int(11) NOT NULL COMMENT '0自动审核1手动审核',
  `cjreplay` tinyint(4) NOT NULL DEFAULT '0' COMMENT '中奖是否需要回复',
  `timeinterval` int(3) NOT NULL DEFAULT '0' COMMENT '观众发送消息的频率，单位秒',
  `shakeopen` tinyint(4) NOT NULL DEFAULT '1' COMMENT '摇一摇开关',
  `voteopen` tinyint(4) NOT NULL DEFAULT '1' COMMENT '投票开关1打开2关闭',
  `votetitle` text NOT NULL COMMENT '投票标题',
  `votefresht` tinyint(4) NOT NULL COMMENT '投票结果刷新时间',
  `circulation` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否循环播放1循环0不循环',
  `refreshtime` tinyint(2) NOT NULL DEFAULT '0' COMMENT '前台刷新时间，单位秒',
  `voteshowway` tinyint(1) DEFAULT '1' COMMENT '投票结果显示方式',
  `votecannum` varchar(255) DEFAULT '1' COMMENT '每个人可以投几票',
  `black_word` text COMMENT '屏蔽关键字',
  `screenpaw` varchar(255) NOT NULL COMMENT '开场密码',
  `rentweixin` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0不借用其他微信号获取用户信息1借用其他微信服务号获取用户信息',
  `copyright` varchar(32) DEFAULT NULL COMMENT '版权',
  `copyrightlink` varchar(500) DEFAULT NULL COMMENT '版权连接',
  `msg_showstyle` tinyint(1) DEFAULT '0' COMMENT '消息显示方式 0滚动1反转',
  `msg_historynum` int(3) DEFAULT '30' COMMENT '循环播放时，循环显示的历史消息数量',
  `msg_showbig` tinyint(1) DEFAULT '0' COMMENT '图片消息是否放大显示0关闭1开启',
  `msg_showbigtime` tinyint(3) DEFAULT '5' COMMENT '开启显示放大图片消息时，显示放大图片的时间，单位是秒',
  `verifycode` varchar(255) DEFAULT NULL COMMENT '活动签到连接校验码',
  `maxplayers` int(11) unsigned DEFAULT '0' COMMENT '0表示不限，大于0表示限制n人数',
  `msg_color` varchar(7) DEFAULT '#4B9E09' COMMENT '16进制颜色值',
  `nickname_color` varchar(7) DEFAULT '#4B9E09' COMMENT '昵称颜色',
  `qrcodetoptext` varchar(255) DEFAULT '扫描下面的二维码参与签到' COMMENT '大二维码顶部文字',
  `msg_num` tinyint(1) DEFAULT '3' COMMENT '微信上墙消息数量 3，4，5，6可选',
  `isclosed` tinyint(1) DEFAULT '1' COMMENT '1开启2关闭',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_wall_config`
--

LOCK TABLES `weixin_wall_config` WRITE;
/*!40000 ALTER TABLE `weixin_wall_config` DISABLE KEYS */;
INSERT INTO `weixin_wall_config` VALUES (1,'你已经成功发送，等待审核通过即可上墙了',0,0,3,1,1,'你最喜欢微信墙的哪个功能？',3,1,3,1,'1','操,sb,傻逼,艹,日你妈,干你妹,老子,bitch,婊子','admin',1,'懒人源码','https://www.lanrenzhijia.com',0,30,0,5,'666c118565b10',0,'#4B9E09','#4B9E09','扫描下面的二维码参与签到',3,1);
/*!40000 ALTER TABLE `weixin_wall_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_weixin_config`
--

DROP TABLE IF EXISTS `weixin_weixin_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_weixin_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) NOT NULL COMMENT '微信名称',
  `erweima` int(11) NOT NULL DEFAULT '0' COMMENT '二维码id',
  `appid` varchar(64) DEFAULT NULL COMMENT '微信appid',
  `appsecret` varchar(128) DEFAULT NULL COMMENT '微信appsecret',
  `mch_id` varchar(255) DEFAULT NULL,
  `mchsecret` varchar(255) DEFAULT NULL,
  `apiclient_cert` text,
  `apiclient_key` text,
  `rootca` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_weixin_config`
--

LOCK TABLES `weixin_weixin_config` WRITE;
/*!40000 ALTER TABLE `weixin_weixin_config` DISABLE KEYS */;
INSERT INTO `weixin_weixin_config` VALUES (1,'微信',0,'','',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `weixin_weixin_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_xiangce`
--

DROP TABLE IF EXISTS `weixin_xiangce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_xiangce` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imagepath` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='相册';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_xiangce`
--

LOCK TABLES `weixin_xiangce` WRITE;
/*!40000 ALTER TABLE `weixin_xiangce` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_xiangce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_xingyunhaoma`
--

DROP TABLE IF EXISTS `weixin_xingyunhaoma`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_xingyunhaoma` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `lucknum` int(11) DEFAULT NULL COMMENT '幸运号码',
  `designated` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1表示普通2表示必中3标识不会中',
  `created_at` int(11) NOT NULL COMMENT '创建时间',
  `ordernum` int(11) NOT NULL COMMENT '第几个抽执行，如果是必中，那就是第几个会出现这个数字，如果是不会中，那就是第几个数字不会出现这个数字',
  `status` tinyint(1) DEFAULT NULL COMMENT '1未中2已中',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='幸运号码记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_xingyunhaoma`
--

LOCK TABLES `weixin_xingyunhaoma` WRITE;
/*!40000 ALTER TABLE `weixin_xingyunhaoma` DISABLE KEYS */;
INSERT INTO `weixin_xingyunhaoma` VALUES (1,717,1,1718362975,1,2),(2,514,1,1718362976,2,2),(3,798,1,1718362977,3,2),(4,942,1,1718362978,4,2),(5,336,1,1718362979,5,2),(6,995,1,1718362980,6,2),(7,772,1,1718362981,7,2),(8,313,1,1718362982,8,2),(9,802,1,1718362983,9,2),(10,624,1,1718362984,10,2),(11,70,1,1718362985,11,2),(12,381,1,1718362986,12,2),(13,527,1,1718362987,13,2),(14,975,1,1718362988,14,2),(15,193,1,1718362989,15,2),(16,959,1,1718362990,16,2),(17,329,1,1718362992,17,2),(18,36,1,1718362993,18,2),(19,375,1,1718363003,19,2),(20,907,1,1718363005,20,2);
/*!40000 ALTER TABLE `weixin_xingyunhaoma` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_xingyunhaoma_config`
--

DROP TABLE IF EXISTS `weixin_xingyunhaoma_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_xingyunhaoma_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `minnum` int(11) NOT NULL DEFAULT '1' COMMENT '幸运号码最小值',
  `maxnum` int(11) NOT NULL DEFAULT '2000' COMMENT '幸运号码最大值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='幸运号码配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_xingyunhaoma_config`
--

LOCK TABLES `weixin_xingyunhaoma_config` WRITE;
/*!40000 ALTER TABLE `weixin_xingyunhaoma_config` DISABLE KEYS */;
INSERT INTO `weixin_xingyunhaoma_config` VALUES (1,1,1000);
/*!40000 ALTER TABLE `weixin_xingyunhaoma_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_xingyunshoujihao`
--

DROP TABLE IF EXISTS `weixin_xingyunshoujihao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_xingyunshoujihao` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `openid` varbinary(255) DEFAULT NULL COMMENT 'openid',
  `designated` tinyint(1) DEFAULT NULL COMMENT '1表示普通2表示必中3标识不会中',
  `ordernum` int(11) DEFAULT NULL COMMENT '第几个抽执行，如果是必中，那就是第几个会出现这个数字，如果是不会中，那就是第几个数字不会出现这个数字',
  `status` tinyint(1) DEFAULT NULL COMMENT '1未中2已中',
  `created_at` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='幸运手机号数据及内定信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_xingyunshoujihao`
--

LOCK TABLES `weixin_xingyunshoujihao` WRITE;
/*!40000 ALTER TABLE `weixin_xingyunshoujihao` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_xingyunshoujihao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_ydj_config`
--

DROP TABLE IF EXISTS `weixin_ydj_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_ydj_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `duration` int(11) NOT NULL DEFAULT '60' COMMENT '持续时间（秒）',
  `winningagain` int(1) DEFAULT '1' COMMENT '0表示不限次数 大于0的数字表示可以获得奖品的次数',
  `joinagain` tinyint(1) DEFAULT NULL COMMENT '1表示不可以重复参加2表示可以（之前参加过活动并得奖的用户是否能重复参与活动）',
  `status` tinyint(1) DEFAULT '1' COMMENT '1表示未开始，2进行中，3表示结束',
  `showstyle` tinyint(1) DEFAULT '1' COMMENT '1昵称2姓名3手机号',
  `themeid` int(11) DEFAULT NULL COMMENT '主题id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='摇大奖游戏配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_ydj_config`
--

LOCK TABLES `weixin_ydj_config` WRITE;
/*!40000 ALTER TABLE `weixin_ydj_config` DISABLE KEYS */;
INSERT INTO `weixin_ydj_config` VALUES (1,30,1,2,1,1,1),(2,30,1,2,1,1,1),(3,30,1,2,1,1,1);
/*!40000 ALTER TABLE `weixin_ydj_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_ydj_record`
--

DROP TABLE IF EXISTS `weixin_ydj_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_ydj_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `point` int(11) DEFAULT NULL COMMENT '数量',
  `userid` int(11) DEFAULT NULL COMMENT '用户id',
  `configid` int(11) DEFAULT NULL COMMENT '配置id',
  `iswinner` tinyint(1) DEFAULT NULL COMMENT '1不是2是中奖用户',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='摇大奖游戏记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_ydj_record`
--

LOCK TABLES `weixin_ydj_record` WRITE;
/*!40000 ALTER TABLE `weixin_ydj_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `weixin_ydj_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weixin_ydj_themes`
--

DROP TABLE IF EXISTS `weixin_ydj_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weixin_ydj_themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `themename` varchar(32) DEFAULT NULL COMMENT '主题名称',
  `themedata` text COMMENT '主题的数据',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='摇大奖游戏配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weixin_ydj_themes`
--

LOCK TABLES `weixin_ydj_themes` WRITE;
/*!40000 ALTER TABLE `weixin_ydj_themes` DISABLE KEYS */;
INSERT INTO `weixin_ydj_themes` VALUES (1,'默认主题','');
/*!40000 ALTER TABLE `weixin_ydj_themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'wxwall'
--

--
-- Dumping routines for database 'wxwall'
--

--
-- Final view structure for view `weixin_view_importlottery`
--

/*!50001 DROP VIEW IF EXISTS `weixin_view_importlottery`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = binary */;
/*!50001 SET character_set_results     = binary */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `weixin_view_importlottery` AS select `weixin_importlottery`.`id` AS `id`,`weixin_importlottery`.`col1` AS `col1`,`weixin_importlottery`.`col2` AS `col2`,`weixin_importlottery`.`col3` AS `col3`,`weixin_importlottery`.`imgid` AS `imgid`,`weixin_user_prize`.`designated` AS `designated`,`weixin_user_prize`.`prizeid` AS `prizeid`,`weixin_user_prize`.`status` AS `status`,`weixin_user_prize`.`verifycode` AS `verifycode`,`weixin_user_prize`.`wintime` AS `wintime`,`weixin_user_prize`.`awardtime` AS `awardtime` from (`weixin_importlottery` left join `weixin_user_prize` on((`weixin_importlottery`.`id` = `weixin_user_prize`.`userid`))) where ((`weixin_user_prize`.`plugname` = 'importlottery') and (`weixin_user_prize`.`activityid` = 1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `weixin_view_lottery`
--

/*!50001 DROP VIEW IF EXISTS `weixin_view_lottery`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = binary */;
/*!50001 SET character_set_results     = binary */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `weixin_view_lottery` AS select `weixin_user_prize`.`id` AS `id`,`weixin_flag`.`id` AS `userid`,`weixin_flag`.`nickname` AS `nickname`,`weixin_flag`.`avatar` AS `avatar`,`weixin_flag`.`signname` AS `signname`,`weixin_flag`.`phone` AS `phone`,`weixin_user_prize`.`activityid` AS `activityid`,`weixin_user_prize`.`prizeid` AS `prizeid`,`weixin_user_prize`.`designated` AS `designated`,`weixin_user_prize`.`status` AS `status`,`weixin_user_prize`.`isdel` AS `isdel` from (`weixin_flag` left join `weixin_user_prize` on((`weixin_flag`.`id` = `weixin_user_prize`.`userid`))) where (`weixin_user_prize`.`plugname` = 'lottery') order by `weixin_flag`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-25  6:36:54
